import java.util.Date;

public class Appointment {
	final private String appointmentID;
	private Date appointmentDate;
	private String desc;
	// CONSTRUCTOR 
	public Appointment(String ID, Date date, String desc) {
		// CEHCK FOR NULL(s)
		if (ID == null || date == null || desc == null) {
			throw new IllegalArgumentException("Invalid Input");
		}
		// CHECK FOR LENGHT
		if (ID.length() > 10 || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Input");
		}
		if (date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Input");
		}
		// IF ALL PASS, ASSIGN VARIABLES
		this.appointmentID = ID;
		this.appointmentDate = date;
		this.desc = desc;
		}
	// GETTERS
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getDate() {
		return appointmentDate;
	}
	
	public String getDesc() {
		return desc;
	}
}
