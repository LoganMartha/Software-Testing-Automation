import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentTest {

	@Test
	void testAppoitnmentClass() {
		Date date = new Date();
		Appointment app = new Appointment("ID", date, "Description");
		assertTrue(app.getAppointmentID().length() < 10 && app.getAppointmentID() != null);
		assertTrue(!app.getDate().before(new Date()));
		assertTrue(app.getDesc().length() < 50 && app.getDesc() != null);
	}
	
	@Test //TEST APP ID
	void testAppID() {
		// TEST FOR NULL (THROWS ERROR IF THERE IS NULL)
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, date, "Description");
		});
		// TEST FOR TOO LONG (THROWS ERROR IF IT IS TOO LONG)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("THIS IS THE APP ID: 123214", date, "Description");
		});
	}
	
	@Test // TEST APP DATE
	void testAppDate() {
		// TEST FOR NULL (THROWS ERROR IF THERE IS NULL)
		long tenDaysInMillis = 10L * 24 * 60 * 60 * 1000; // VALUE TO SUBTRACT TO MAKE A PAST DATE
		Date date = new Date(System.currentTimeMillis() - tenDaysInMillis); // PAST DATE
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("ID", null, "Description");
		});
		// TEST FOR DATE BEING BEFORE
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("ID", date, "Description");
		});
	}
	
	@Test //TEST APP DESC
	void tesAppDesc() {
		// TEST FOR NULL (THROWS ERROR IF THERE IS NULL)
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("ID", date, null);
		});
		// TEST FOR TOO LONG (THROWS ERROR IF IT IS TOO LONG)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("ID", date, "This Description is too long for the requriement... It must be changed");
		});
	}
}
