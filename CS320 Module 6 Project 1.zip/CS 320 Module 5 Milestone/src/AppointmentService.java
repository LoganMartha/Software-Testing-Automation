import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	// ADD NEW APPOINTMENT
	public void addAppointment(String ID, Date date, String desc) {
		// SEARCH EXISTING APPOINTMENTS IN LIST FOR MATCHING ID
		for(int i = 0; i < appointmentList.size(); ++i) {
			if (ID == appointmentList.get(i).getAppointmentID()) {
				throw new IllegalArgumentException("Appointment With this ID already Exists");
			}
		}
		// NO MATCHING ID SO ADD NEW APPOINTMENT TO LIST
		Appointment appointment = new Appointment(ID, date, desc);
		appointmentList.add(appointment);
	}
	
	// DELETE APPOINTMENT
	public void deleteAppointment(String ID) {
		// SEARCH EXISTING APPOINTMENTS IN LIST FOR MATCHING ID
		for(int i = 0; i < appointmentList.size(); ++i) {
			if (ID == appointmentList.get(i).getAppointmentID()) {
				appointmentList.remove(i);
				break;
			}
			// NO MATCHING ID AND AT END OF LIST SO THROW ERROR
			if (i == appointmentList.size() - 1) {
				throw new IllegalArgumentException("Appointment with that ID does not Exsist");
			}
		}		
	}
}