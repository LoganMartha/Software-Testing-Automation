import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentServiceTest {
	// Code used Before Each Test
	Date date = new Date();
	AppointmentService service = new AppointmentService();
	Appointment app = new Appointment("ID", date, "Description");
	
	@Test //TEST ADD APP (ERROR BECAUSE MATCHING ID)
	void testAddApp() {
		//INVALID ADD APP
		service.appointmentList.add(app);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment("ID", date, "Description");
		});
		//VALID ADD APP
		Date date2 = new Date();
		service.addAppointment("ID2", date2, "Description");
		assertEquals(2, service.appointmentList.size(), "This list should be 2");
	}
	
	@Test // TEST DELETE APP (ERROR BECAUSE NO MATCHING ID)
	void testDeleteApp() {
		//INVALID DELETE APP
		service.appointmentList.add(app);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment("IDs");
		});
		//VALID DELETE APP
		service.deleteAppointment("ID");
		assertEquals(0, service.appointmentList.size(), "The list should be empty");
	}
}