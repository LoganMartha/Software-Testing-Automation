import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test // Task Test Class
	void testTaskClass() {
		Task task = new Task("Test", "TestTask", "This is the test description");
		assertTrue(task.getTaskID().length() < 10 || task.getTaskID() != null);
		assertTrue(task.getName().length() < 20 || task.getName() != null);
		assertTrue(task.getDesc().length() < 50 || task.getDesc() != null);
	}
	@Test //TEST TASK ID
	void testTaskID() {
		// TEST FOR NULL (THROWS ERROR IF THERE IS NULL)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Task Test", "This is the test description");
		});
		// TEST FOR TOO LONG (THROWS ERROR IF IT IS TOO LONG)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("THIS IS THE TEST ID: 123214", "TestTask", "This is the test description");
		});
	}
	
	@Test //TEST NAME
	void testName() {
		// TEST FOR NULL
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("Test", null, "This is the test description");
		});
		// TEST FOR LENGTH
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("Test", "THIS NAME IS TOO LONG TO BE A NAME FOR THE CLASS", "This is the test description");
		});
	}
	
	@Test //TEST DESC
	void testDesc() {
		// TEST FOR NULL
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("Test", "TestTask", null);
		});
		//TEST FOR LENGTH
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("Test", "TestTask", "THIS IS SUPPOSE TO BE LONGER THAT 50 CHARACTERS TO TEST FOR THE TEST.... I THINK I NEED TO MAKE IT LONGER IDK THO");
		});
	}
	@Test //TEST SET NAME
	void testSetName() {
		// TEST FOR NULL
		Task task = new Task("Test", "TestTask", "This is the test description");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			task.setName(null);
		});
		//TEST FOR LENGTH
		Task task1 = new Task("Test", "TestTask", "This is the test description");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			task1.setName("THIS NAME IS TOO LONG TO BE A NAME FOR THE CLASS");
		});
	}
	
	@Test // TEST SET DESCRIPTION
	void testSetDesc() {
		// TEST FOR NULL
		Task task = new Task("Test", "TestTask", "This is the test description");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			task.setDesc(null);
		});
		Task task1 = new Task("Test", "TestTask", "This is the test description");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			task.setDesc("THIS IS SUPPOSE TO BE LONGER THAT 50 CHARACTERS TO TEST FOR THE TEST.... I THINK I NEED TO MAKE IT LONGER IDK THO");
		});
	}
}
