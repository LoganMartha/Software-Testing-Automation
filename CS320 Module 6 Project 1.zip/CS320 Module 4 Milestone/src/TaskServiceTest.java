import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	// Code Used Before Each Test
	TaskService service = new TaskService();
	Task task = new Task("Test", "TestTask", "This is the test description");
	
	@Test //TEST ADD TASK
	void testAddTask() {
		//INVALID ADD TASK
		service.taskList.add(task);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addTask("Test", "NAME", "DESC");
		});
		//VALID ADD TASK
		service.addTask("Test2", "Name", "DESC");
		assertEquals(2, service.taskList.size(), "Task list should have 2 contacts.");
	}
	
	@Test //TEST DELETE TASK
	void testDeleteTask() {
		//INVALID DELETE TASK
		service.taskList.add(task);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteTask("TESTER");
		});
		//VALID DELETE TASK
		service.deleteTask("Test");
		assertEquals(0, service.taskList.size(), "Task List should have no contacts.");
	}
	
	@Test //TEST CHANGE NAME
	void testChangeName() {
		//INVALID CHANGE NAME
		service.taskList.add(task);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.changeName("newName", "TESTER");
		});
		//VALID CHANGE NAME
		service.changeName("newName", "Test");
		assertEquals("newName", service.taskList.get(0).getName(), "The task's name should have changed.");
	}
	
	@Test //TEST CHANGE DESCRIPTION
	void testChangeDesc() {
		service.taskList.add(task);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.changeDesc("newDesc", "TESTER");
		});
		//VALID CHANGE DESC
		service.changeDesc("newDesc", "Test");
		assertEquals("newDesc", service.taskList.get(0).getDesc(), "The task's desc should have changed.");
	}
}
