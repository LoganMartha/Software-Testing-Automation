import java.util.ArrayList;

public class TaskService {
	//List of Tasks
	public ArrayList<Task> taskList = new ArrayList<Task>();
	// ADD TASK
	public void addTask(String taskID, String name, String desc) {
		for (int i = 0; i < taskList.size(); ++i) {
			// Task with ID already Exist
			if (taskID == taskList.get(i).getTaskID()) {
				throw new IllegalArgumentException("That Tast ID already Exists");
			}	
		}
		// Create new Task
		Task task = new Task(taskID, name, desc);
		// Add new task to taskList
		taskList.add(task);	
	}
	// DELETE TASK
	public void deleteTask(String taskID) {
		for (int i = 0; i < taskList.size(); ++i) {
			// If task matches, delete from list
			if (taskID == taskList.get(i).getTaskID()) {
				taskList.remove(i);
				break;
			}
			// Reach end of list and no match
			if(i == taskList.size() - 1) {
				throw new IllegalArgumentException("Task ID Not Found");
			}
		}
	}
	// CHANGE NAME
	public void changeName(String newName, String taskID) {
		for (int i = 0; i < taskList.size(); ++i) {
			// If task ID matches, name is updated
			if (taskID == taskList.get(i).getTaskID()) {
				taskList.get(i).setName(newName);
				break;
			}
			// Reach end of list and no matching ID
			if(i == taskList.size() - 1) {
				throw new IllegalArgumentException("Task ID Not Found");
			}
		}
	}
	// CHANCE DESC
	public void changeDesc(String newDesc, String taskID) {
		for (int i = 0; i < taskList.size(); ++i) {
			// If task ID matches, desc is updated
			if (taskID == taskList.get(i).getTaskID()) {
				taskList.get(i).setDesc(newDesc);
				break;
			}
			// Reach end of list and no matching ID
			if(i == taskList.size() - 1) {
				throw new IllegalArgumentException("Task ID Not Found");
			}
		}
	}
}

