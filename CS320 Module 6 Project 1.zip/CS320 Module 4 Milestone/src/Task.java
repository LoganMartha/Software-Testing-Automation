
public class Task {
	
	final private String taskID;
	private String name;
	private String desc;
	
	//Condition Requirements for object values
	public Task(String taskID, String name, String desc) {
		// CHECK FOR NULL(s)
		if (taskID == null || name == null || desc == null) {
			throw new IllegalArgumentException("Invalid Input");
		}
		// CEHCK FOR LENGTH(s)
		if (taskID.length() > 10 || name.length() > 20 || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.taskID = taskID;
		this.name = name;
		this.desc = desc;
	}
	// GETTERS
	public String getTaskID() {
		return taskID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDesc() {
		return desc;
	}
	
	// Setters
	
	public void setName(String newName) {
		// newName must meet requirements 
		if (newName == null || newName.length() > 20) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.name = newName;
	}
	
	public void setDesc(String newDesc) {
		if (newDesc == null || newDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.desc = newDesc;
	}
}
