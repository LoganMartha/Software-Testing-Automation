import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class ContactTest  {

	@Test //CONTACT CLASS TEST
	void testContactClass() {
		Contact contact = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		assertTrue(contact.getContactID() != null || contact.getContactID().length() < 10);
		assertTrue(contact.getFirstName() != null || contact.getFirstName().length() < 10);
		assertTrue(contact.getLastName() != null || contact.getLastName().length() < 10);
		assertTrue(contact.getPhone() != null || contact.getPhone().length() < 10);
		assertTrue(contact.getAddress() != null || contact.getAddress().length() < 30);
		}
	
	@Test // CONTACTID TEST
	void testContactID() {
		// TEST FOR NULL (THROWS ERROR IF THERE IS NULL)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Logan", "Martha", "7247994234", "6187 Brown Road"); 
		});
		// TEST FOR TOO LONG (THROWS ERROR IF IT IS TOO LONG)
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "Logan", "Martha", "7247994234", "6187 Brown Road"); 
		});
		
	}
	
	@Test // FIRSTNAME TEST
	void testFirstName() {
		// TEST FOR NULL
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", null, "Martha", "7247994234", "6187 Brown Road"); 
		});
		// TEST FOR TOO LONG
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "LoganChristopher", "Martha", "7247994234", "6187 Brown Road"); 
		});
		
	}
	
	@Test // LASTNAME TEST
	void testLastName() {
		// TEST FOR NULL
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Logan", null, "7247994234", "6187 Brown Road"); 
		});
		// TEST FOR TOO LONG
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Logan", "ChristopherMartha", "7247994234", "6187 Brown Road"); 
		});
		
	}
	
	@Test // PHONE TEST
	void testPhone() {
		// TEST FOR NULL
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Logan", "Martha", null, "6187 Brown Road"); 
		});
		// TEST FOR TOO LONG
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Logan", "Martha", "72479942341", "6187 Brown Road"); 
		});
		
	}
	@Test // ADDRESS TEST
	void testAddress() {
		// TEST FOR NULL
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Logan", "Martha", "7247994234", null); 
		});
		// TEST FOR TOO LONG
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road Butler Pennsylvania 16002"); 
		});
		
	}
	
	@Test // CHANGE FIRSTNAME TEST
	void testChangeFirstName() {
		// TEST FOR NULL CHANGE
		Contact contact = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName(null); 
		});
		// TEST FOR TOO LONG
		Contact contact1 = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact1.setFirstName("LoganChristopher"); 
		});
		
	}
	
	@Test // CHANGE LASTNAME TEST
	void testChangeLastName() {
		// TEST FOR NULL CHANGE
		Contact contact = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName(null); 
		});
		// TEST FOR TOO LONG
		Contact contact1 = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact1.setLastName("ChristopherMartha"); 
		});
	}
	@Test // CHANGE FIRSTNAME TEST
	void testChangePhone() {
		// TEST FOR NULL CHANGE
		Contact contact = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setPhone(null); 
		});
		// TEST FOR TOO LONG
		Contact contact1 = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact1.setPhone("724-799-4234"); 
		});
		
	}
	@Test // CHANGE FIRSTNAME TEST
	void testChangeAddress() {
		// TEST FOR NULL CHANGE
		Contact contact = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress(null); 
		});
		// TEST FOR TOO LONG
		Contact contact1 = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Road");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact1.setAddress("6187 Brown Road Butler Pennsylvania 16002"); 
		});
		
	}

	
	
}

