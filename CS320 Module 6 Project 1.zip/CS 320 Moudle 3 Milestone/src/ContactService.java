import java.util.ArrayList;


public class ContactService {
	// List of Contacts
	public ArrayList<Contact> contactList = new ArrayList<Contact>();
	// ADD CONTACT
	public void addContact(String contactID, String firstName, String lastName, String phone, String address) {
		// Check for duplicate ID and Add if not there
		for (int i = 0; i < contactList.size(); ++i) {
			if(contactList.get(i).getContactID() == contactID) {
				throw new IllegalArgumentException("Contact ID Already Exists");
			} 
		}
		// Add New Contact if No Duplicate ID
		Contact contact = new Contact(contactID, firstName, lastName, phone, address);
		contactList.add(contact);
	}
	// DELETE CONTACT
	public void deleteContact(String contactID) {
		// Check for same ID to Delete
		for (int i = 0; i < contactList.size(); ++i) {
			if(contactList.get(i).getContactID() == contactID) {
				contactList.remove(i);
				break;
			}
			// End of List w/ no Matching ID
			if(i == contactList.size() - 1) {
				throw new IllegalArgumentException("Contact ID Not Found");
			}
		}
	}
	// CHANGE FIRST NAME
	public void changeFirstName(String contactID, String newName) {
		for (int i = 0; i < contactList.size(); ++i) {
			if(contactList.get(i).getContactID() == contactID) {
				contactList.get(i).setFirstName(newName);
				break;
			}
			// End of List w/ no Matching ID
			if(i == contactList.size() - 1) {
				throw new IllegalArgumentException("Contact ID Not Found");
			}
		}
	}
	// CHANGE LAST NAME
	public void changeLastName(String contactID, String newName) {
		for (int i = 0; i < contactList.size(); ++i) {
			if(contactList.get(i).getContactID() == contactID) {
				contactList.get(i).setLastName(newName);
				break;
			}
			// End of List w/ no Matching ID
			if(i == contactList.size() - 1) {
				throw new IllegalArgumentException("Contact ID Not Found");
			}
		}
	}
	// CHANGE PHONE NUMBER
	public void changePhone(String contactID, String newPhone) {
		for (int i = 0; i < contactList.size(); ++i) {
			if(contactList.get(i).getContactID() == contactID) {
				contactList.get(i).setPhone(newPhone);
				break;
			}
			// End of List w/ no Matching ID
			if(i == contactList.size() - 1) {
				throw new IllegalArgumentException("Contact ID Not Found");
			}
		}
	}
	// CHANGE ADDRESS 
	public void changeAddress(String contactID, String newAddress) {
		for (int i = 0; i < contactList.size(); ++i) {
			if(contactList.get(i).getContactID() == contactID) {
				contactList.get(i).setAddress(newAddress);
				break;
			}
			// End of List w/ no Matching ID
			if(i == contactList.size() - 1) {
				throw new IllegalArgumentException("Contact ID Not Found");
			}
		}
	}
}

