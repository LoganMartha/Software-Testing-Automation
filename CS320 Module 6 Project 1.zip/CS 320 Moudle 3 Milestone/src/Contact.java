
public class Contact {
	
	// Attributes for Contact Class
	final private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	// Constructor
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
		// Requirements to Meet else Error Message
		//CONTACT ID
		if(contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		// FIRST NAME
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		// LAST NAME
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		
		// PHONE NUMBER
		if (phone == null || phone.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		// ADDRESS
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		// Create Contact Object With Values if Meet Requirements
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	// GETTERS
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;	
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	// SETTERS
	
	public void setFirstName(String setName) {
		if (setName == null || setName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = setName;
	}
	
	public void setLastName(String setName) {
		if (setName == null || setName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = setName;
	}
	
	public void setPhone(String setPhone) {
		if (setPhone == null || setPhone.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		this.phone = setPhone;
	}
	
	public void setAddress(String setAddress) {
		if (setAddress == null || setAddress.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.address = setAddress;
	}
}
