import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	// Code Used Before Each Test (Couldn't do @BeforeTest annotation because it wouldn't fine "service" being initiated)
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Logan", "Martha", "7247994234", "6187 Brown Rd");
	// ADD CONTACT
		
	@Test
	void testAddContact() {
		//INVALID ADD CONTACT TEST
		service.contactList.add(contact);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addContact("1", "Jack", "Martha", "7247991234", "6188 Brown Rd");
		});
		//VALID ADD CONTACT TEST
		Contact validContact = new Contact("2", "Jack", "Martha", "7247991234", "6188 Brown Rd");
		service.contactList.add(validContact);
		assertEquals(2, service.contactList.size(), "Contact list should have 2 contacts.");
	}
	// DELETE CONTACT
	@Test
	void testdeleteContact() {
		//INVALID DELETE CONTACT TEST
		service.contactList.add(contact);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteContact("2");
		});
		//VALID DELETE CONTACT TEST
		service.deleteContact("1");
		assertEquals(0, service.contactList.size(), "Contact list should have deleted one contact.");
	}
	
	// CHANGE FIRSTNAME
		@Test
		void testChangeFirstName() {
			//INVALID CHANGE FIRST NAME
			service.contactList.add(contact);
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				service.changeFirstName("2", "Jack");
			});
			//VALID CHANGE FIRST NAME
			service.changeFirstName("1", "Jack");
			assertEquals("Jack", service.contactList.get(0).getFirstName());
		}
	// CHANGE LASTNAME
		@Test
		void testChangeLastName() {
			//INVALID CHANGE LAST NAME
			service.contactList.add(contact);
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				service.changeLastName("2", "Johnson");
			});
			//VALID CHANGE LAST NAME
			service.changeLastName("1", "Johnson");
			assertEquals("Johnson", service.contactList.get(0).getLastName());
		}
	// CHANGE PHONE
		@Test
		void testChangePhone() {
			//INVALID CHANGE PHONE NUMBER
			service.contactList.add(contact);
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				service.changePhone("2", "7247991234");
			});
			//VALID CHANGE PHONE NUMBER
			service.changePhone("1", "3145419990");
			assertEquals("3145419990", service.contactList.get(0).getPhone());
		}
	// CHANGE ADDRESS
		@Test
		void testChangeAddress() {
			//INVALID CHANGE ADDRESS
			service.contactList.add(contact);
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				service.changeAddress("2", "6188 Brown Rd");
			});
			//VALID CHANGE ADDRESS
			service.changeAddress("1", "1212 Joseph Court");
			assertEquals("1212 Joseph Court", service.contactList.get(0).getAddress());
		}
}
